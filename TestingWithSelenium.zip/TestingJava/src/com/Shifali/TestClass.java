package com.Shifali;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestClass {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\browserdrivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.trustedshops.de/bewertung/info_X77B11C1B8A5ABA16DDEC0C30E7996C21.html");
		
        // Wait for the cookie pop-up to appear and accept it
        WebDriverWait wait = new WebDriverWait(driver, 2);
        WebElement acceptButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("uc-btn-accept-banner")));
        acceptButton.click();
        // Switch back to the default content (main page)
        driver.switchTo().defaultContent();
        
        
		// 1. Check if the page title exists
        String pageTitle = driver.getTitle();
        if (pageTitle != null && !pageTitle.isEmpty()) {
           System.out.println("Page title: " + pageTitle);
       } else {
           System.out.println("Page title not found");
       }

        // 2. Check if the grade is visible and above zero
        WebElement gradeElement = driver.findElement(By.className("ctgork"));
        String gradeText = gradeElement.getText();
        double gradeValue = Double.parseDouble(gradeText.replace(",", "."));
        if (gradeValue > 0) {
            System.out.println("Grade: " + gradeText);
        } else {
           System.out.println("Grade not found or below zero");
        }

        // 3. Check if the "Wie berechnet sich die Note?" link opens the window with additional information
        WebElement infoLink = driver.findElement(By.linkText("Wie berechnet sich die Note?"));
        infoLink.click();

        // Switch to the new window
        String windowHandle = driver.getWindowHandle();
        driver.switchTo().window(windowHandle);

        // Wait for the info-content element to be present
        WebDriverWait wait1 = new WebDriverWait(driver, 5);
        WebElement infoContent = wait1.until(ExpectedConditions.presenceOfElementLocated(By.className("bheJZy")));

        // Get the text from the info-content element
        String infoText = infoContent.getText();

        if (infoText != null && !infoText.isEmpty()) {
            System.out.println("Additional information: " + infoText);
        } else {
            System.out.println("Additional information not found");
        }
        driver.switchTo().defaultContent();
        
        // 4. Click on "2 Stars" to filter all "two stars" reviews
        WebElement twoStarsFilter = driver.findElement(By.className("hucPgJ"));

        // Scroll the element into view
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", twoStarsFilter);

        // Wait for the element to be clickable
        WebDriverWait wait3 = new WebDriverWait(driver, 10);
        WebElement elementToClick = wait3.until(ExpectedConditions.elementToBeClickable(twoStarsFilter));

        // Click on the element using JavaScriptExecutor
        js.executeScript("arguments[0].click();", elementToClick);

        // Verify that every review in the entire list has only two stars
        List<WebElement> reviewElements = driver.findElements(By.className("review"));

        boolean allTwoStars = true;
        for (WebElement reviewElement : reviewElements) {
            WebElement starRatingElement = reviewElement.findElement(By.className("star-rating"));
            String starRatingText = starRatingElement.getText();

            if (!starRatingText.equals("2 Stars")) {
                allTwoStars = false;
                break;
            }
        }

        if (allTwoStars) {
            System.out.println("All the filtered out reviews have only two stars");
        } else {
            System.out.println("Not all the filtered reviews have only two stars");
        }
       
       // 5. Create the sum of all star percentage values
        WebElement starPercentageContainer = driver.findElement(By.className("jEoVFS"));
        String starPercentageText = starPercentageContainer.getText();

        // Extract the percentage values and calculate the sum
        String[] starPercentageValues = starPercentageText.split("\\s+");
        double sumOfStarPercentages = 0.0;

        for (String percentage : starPercentageValues) {
            // Remove the percentage sign (%) from the value
            String cleanPercentage = percentage.replaceAll("%", "");
            // Check if the cleaned percentage is not empty
            if (!cleanPercentage.isEmpty()) {
                // Parse the cleaned percentage as a double
                double starPercentage = Double.parseDouble(cleanPercentage);

                // Check if adding the current star percentage exceeds 100
                if (sumOfStarPercentages + starPercentage <= 100.0) {
                    // Add the star percentage to the sum
                    sumOfStarPercentages += starPercentage;
                }
            }
        }

        // Format the sum of star percentages with the desired number format
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.GERMANY);
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.0", symbols);
        String formattedSum = decimalFormat.format(sumOfStarPercentages);

        System.out.println("Sum of star percentages: " + formattedSum);
       
       // Close the browser
       driver.quit();
  }
}